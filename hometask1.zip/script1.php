<?php
$name = readline("Как Ваше имя ? ");
$age = readline("Какой у Вас возраст ? ");
echo "Ваше имя $name. Ваш возраст $age.";

