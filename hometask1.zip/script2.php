<?php
$name = readline("Как Ваше имя ? ");
$task1 = readline("Какая задача стоит перед вами сегодня? ");
$task1_result = readline("Сколько во времени займет эта задача ");
$task2 = readline("Какая еще задача стоит перед вами сегодня? ");
$task2_result = readline("Сколько во времени займет эта задача ");
$task3 = readline("Какая еще задача стоит перед вами сегодня? ");
$task3_result = readline("Сколько во времени займет эта задача ");
$total_result = $task1_result + $task2_result + $task3_result;
echo "Итак, примерно время выполнения плана $total_result ч.";

